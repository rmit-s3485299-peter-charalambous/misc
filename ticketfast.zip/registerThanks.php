<?php

include 'includes/nav2.php';

?>


<br>
<br>
<br>
<br>
<br>



			<h3 style='text-align:center;'>Thank you for registering!</h3>
		    <h5 style='text-align:center;'>You will be redirected to the Home page in 5 seconds</h5>
			<h5 style='text-align:center;'>If you have not been redirected, please click <a href='index.php'>here</a></h5>
<?php
include 'includes/footer.php';
?>