  <div class="navbar navbar-default navbar-fixed-bottom">
    <div class="container-fluid" id="footer">
      <!--http://www.freeiconspng.com/img/38347-->
      <a href = "https://www.facebook.com/" target="facebook"><img class="footersm" src ="facebookLogo.png"/></a>
      <!--https://en.wikipedia.org/wiki/File:Twitter_bird_logo_2012.svg-->
      <a href = "https://twitter.com/?lang=en" target="twitter"><img class ="footersm" src ="twitterLogo.png"/></a><br><br>
      <p>&copy; Peter Charalambous, Nelson Petrovski, Evans Sam & Aleksandar Vujatovic 2017</p>  
    </div>
  </div>