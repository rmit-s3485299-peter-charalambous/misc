<!DOCTYPE html>
<?php
session_start();
?>
<html lang="en">
  
<head> 
	 
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width = device-width, initial-scale = 1, shrink-to-fit=no">
	

<!--	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css"> -->
	<link rel="shortcut icon" href="/favicon.jpg"/>
  <link href="bootstrap.min.css" rel="stylesheet">
	<link href="style.css" rel="stylesheet">	
	<link rel="stylesheet" media="screen and (max-width: 767.5px)" href="navcollapse.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
 <script src="bootstrap.min.js"></script> 

  
  </head>
<body>
  
  <!-- responsive navbar for mobiles -->
  
  <nav class="navbar navbar-default">
  <div class="container-fluid">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
  <a class="navbar-brand" rel="home" href="index.php">
    <img id="logo" src="favicon.jpg">
  </a>
  </div>
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="index.php"><span class="navedit" id="home">Home</span></a></li>
        <li><a href="aboutUs.php"><span class="navedit">About Us</span></a></li>
        <li><a href="faq.php"><span class="navedit">FAQ</span></a></li>
        <li><a href="contactUs.php"><span class="navedit">Contact Us</span></a></li>
        <li class='register' id='register'><a href="register.php"><span class="navedit">Register</span></a></li>
      </ul>
      
    <!-- Login form -->
      
    <div class="loginForm" id="loginForm">
      
    <form class="navbar-form navbar-right" role="search" method="post" action="checkLogin.php">
     
     <div class="form-group">
          <input type="text" class="form-control" name="myusername" placeholder="Username">
      </div>
      
      
      <div class="form-group">
          <input type="password" class="form-control" name="mypassword" placeholder="Password">
         
      </div>
      <button type="submit" class="btn btn-default">Sign In</button>
    </form>
    
    <!-- Forgot password feature -->
    <a href="passwordForgot.php" class="navbar-right fp">Forgot Password?</a>
    <p class="navbar-right fp text-danger bg-danger"><?=$_SESSION['loginError']?></p>
    </div>  
    
    
    <div class="loggedIn" id="loggedIn">

    <!-- Dropdown menu on nav bar -->
      
<div class="btn-group navbar-form navbar-right">
  <button type="button" class="btn btn-primary"><?= $_SESSION['username']?></button>
  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <span class="caret"></span>
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <ul class="dropdown-menu">
    <li><a href="profile.php">Profile</a></li>
    <li><a href="purchasehistory.php">Purchase History</a></li>
    <li role="separator" class="divider"></li>
    <li><a href="signOut.php">Sign out</a></li>
  </ul>
</div>
      
    </div>
    
    
    </div>
  </div>
  </nav>
        <!--  <div class="visible alert alert-danger alert-dismissable fade in errorMSG">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      <?//=$_SESSION['loginError'] ?>
    </div> -->
  <div id ="title">
    <img id="logo2" src="favicon2.jpg"/>
  </div>
  
  
  
  </body>
      <?php
    $username = $_SESSION['username'];
?>


<style>
  .loginForm{
  display: block;
}

.loggedIn{
  display: none; /*hidden by default */
}
.fp{
  inline-size: -webkit-fill-available;
  text-align: right;
  padding-right: 4.8%;
}
.register{
  display:block;
}
</style>
  <script>
    
    var loginForm = document.getElementById('loginForm');
    var loggedIn = document.getElementById('loggedIn');
    var username = '<?php echo $username; ?>';
    var reg = document.getElementById('register');
    
    if(username != ""){
      loginForm.style.display = "none";
      loggedIn.style.display = "block";
      reg.style.display = "none";
    }
    

  </script>
    <style>
        .loginError{
            display: none;
        }

</style>
<?php
$_SESSION['site'] = $_SERVER['SERVER_NAME']  . $_SERVER['REQUEST_URI'];

?>

<?php 
  if($_SESSION['loginError'] != ''):?>
<script>
      $(".loginError").css('display', 'block');
</script>
<?php endif; ?>

<?php 
if($_SESSION['site'] != ['SERVER_NAME']  . $_SERVER['REQUEST_URI']):?>

  <script>
      $(".loginError").css('display', 'none');

</script>
<?php $_SESSION['loginError'] = '';
endif; ?>