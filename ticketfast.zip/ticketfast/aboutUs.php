<?php
session_start();
include 'includes/nav.php';

?>
  	<title>TicketFast | About Us</title>
  	
  	<!-- About Us information -->
  	
  <article>
    <div id="aboutUs">
        <p1>At TicketFast, we utilise modern day technology to ensure that our customers are presented with the most accurate events 
            that corresponds with their interests. Founded in 2017, TicketFast has partnered up with sports and live entertainment 
            industries which will allow us to grow and provide the biggest and most exciting events to our customers.<br><br>
            TicketFast provides tickets to events through all of Australia, which includes some of Australia’s biggest venues including 
            Melbourne Cricket Ground, ANZ Stadium, Qudos Bank Arena, Sydney Cricket Ground and many more. 
        </p1>
    </div>
  </article>
  
<?php

include 'includes/footer.php';

?>

</body>
</html>